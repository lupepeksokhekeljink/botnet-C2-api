LICENSE (INDONESIA)

⚠️ PERHATIAN! KODE INI DILINDUNGI HAK CIPTA ⚠️

© 2025 Andrax. Semua Hak Dilindungi.

Kode ini adalah properti eksklusif dari pemiliknya. DILARANG KERAS melakukan hal berikut tanpa izin tertulis dari pemilik:

Menyalin, membagikan, atau mendistribusikan kode ini dalam bentuk apa pun.

Menjual, menyewakan, atau memberikan kode ini ke pihak lain.

Mengedit, memodifikasi, atau mengklaim kode ini sebagai milik sendiri.


🚨 PELAPORAN & KONSEKUENSI HUKUM 🚨
Siapa pun yang melanggar lisensi ini akan DILAPORKAN dan bisa dikenakan tuntutan hukum sesuai dengan hukum yang berlaku.

JIKA ANDA TIDAK MENDAPATKAN IZIN RESMI, JANGAN GUNAKAN KODE INI!

KALAU INGIN RE-SELLER YA BELI RE SELLER KONTOL PM GUA AJA
t.me/HANZ_OVH_FLOOD
---



LICENSE (ENGLISH)

⚠️ WARNING! THIS CODE IS COPYRIGHTED ⚠️

© 2025 Andrax. All Rights Reserved.

This code is exclusive property of the owner. STRICTLY PROHIBITED without written permission from the owner:

Copying, sharing, or distributing this code in any form.

Selling, renting, or giving this code to others.

Editing, modifying, or claiming this code as your own.


🚨 REPORTING & LEGAL CONSEQUENCES 🚨
Anyone violating this license WILL BE REPORTED and may face legal action under applicable laws.

IF YOU DO NOT HAVE OFFICIAL PERMISSION, DO NOT USE THIS CODE!

IF YOU WANT TO RE-SELL, BUY A RE-SELLER, JUST PM ME
t.me/HANZ_OVH_FLOOD
---